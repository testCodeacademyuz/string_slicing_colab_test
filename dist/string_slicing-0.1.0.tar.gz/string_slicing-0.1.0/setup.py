from setuptools import setup

setup(
   name='string_slicing',
   version='0.1.0',
   packages=['string_slicing'],
   description='This is String Slicing Test',
   install_requires=[
       "requests",
   ]
)