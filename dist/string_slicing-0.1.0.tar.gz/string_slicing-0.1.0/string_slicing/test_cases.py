test_cases = {
    "taskOne":[
        {
            "input": ["codeacademy"],
            "expected": "code"
        },
        {
            "input": ["python"],
            "expected": "pyth"
        },
        {
            "input": ["code"],
            "expected": "code"
        },
    ],
    "taskTwo":[
        {
            "input": ["hello world"],
            "expected": "orld"
        },
        {
            "input": ["python"],
            "expected": "ython"
        },
    ]
}
