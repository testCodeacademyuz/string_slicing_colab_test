from string_slicing import (
    TaskOne,
    TaskTwo
)

q1 = TaskOne("slicing01", "string_slicing")
q2 = TaskTwo("slicing02", "string_slicing")