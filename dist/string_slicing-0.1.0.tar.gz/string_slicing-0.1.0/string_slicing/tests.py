from string_slicing import (
    TaskOne,
    TaskTwo,
    TaskThree
)

q1 = TaskOne("slicing01", "string_slicing")
q2 = TaskTwo("slicing02", "string_slicing")
q3 = TaskThree("slicing03", "string_slicing")   