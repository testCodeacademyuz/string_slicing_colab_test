from string_slicing import (
    TaskOne
)

q1 = TaskOne("slicing01", "string_slicing")