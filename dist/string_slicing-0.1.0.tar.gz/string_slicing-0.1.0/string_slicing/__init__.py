from .checker import CheckSolution
from .test_cases import test_cases
from .test01 import TaskOne
from .test02 import TaskTwo